<?php

$string = $_GET["ch"];

$_SESSION['random_number'] = $string;

$dir = 'fonts/';

$image = imagecreatetruecolor(60, 60);

// random number 1 or 2
$num = rand(1,2);
$font = "Molot.otf";// font style
$color = imagecolorallocate($image, 248, 55, 205);// color
$white = imagecolorallocate($image, 48, 48, 48); // background color white
imagefilledrectangle($image,0,0,399,99,$white);

imagettftext ($image, 30, 0, 10, 40, $color, $dir.$font, $_SESSION['random_number']);

header("Content-type: image/png");
imagepng($image);

?>