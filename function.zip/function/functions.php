<?php
function mypackage(){
	global $db;
	$st=$db->getVal("select mid from ".USERMEMBERSHIP." where uid='".$_SESSION["user"]["uid"]."' and status=1");
	return $st;
}
function img($image){
	$type = pathinfo($image, PATHINFO_EXTENSION);
	$data = file_get_contents($image);
	return 'data:image/' . $type . ';base64,' . base64_encode($data);
}
function mypackageDetail(){
	global $db;global $objdeal;
	$st=$db->getRow("select * from ".USERMEMBERSHIP." where uid='".$_SESSION["user"]["uid"]."' and status=1");
	if(is_array($st) && count($st)>0){
		$st["name"]=$db->getVal("select name from ".MEMBERSHIPS." where id='".$st["mid"]."'");
		return $st;
	}else{
		$st=$db->getVal("select id from ".USERMEMBERSHIP." where uid='".$_SESSION["user"]["uid"]."'");
		if($st==""){
			$defaultPlan=$db->getVal("select id from ".MEMBERSHIPS." where is_default=1 and status=1");
			$pac=$objdeal->savePackage($defaultPlan,$_SESSION["user"]["uid"]);
			$st=$db->getRow("select * from ".USERMEMBERSHIP." where uid='".$_SESSION["user"]["uid"]."' and status=1");
			$st["name"]=$db->getVal("select name from ".MEMBERSHIPS." where id='".$st["mid"]."'");
			return $st;
		}
	}
}
function get_currency($amount, $from_Currency, $to_Currency) {
	global $db;
	$to=0;$from=0;
	$to1 = $db->getVal("select cur_rate from ".CURRENCY." where cur_name ='".$to_Currency."'");
	$from1 = $db->getVal("select cur_rate from ".CURRENCY." where cur_name ='".$from_Currency."'");
	$returnData = ($amount * ($to1/$from1));
	//echo $to1."-".$from1.$db->getLastQuery();exit;
	return $returnData;
}
function currency($amount, $from_Currency, $to_Currency) {
	$amount = urlencode($amount);
	$from_Currency = urlencode($from_Currency);
	$to_Currency = urlencode($to_Currency);
	$url = "http://www.google.com/finance/converter?a=$amount&from=$from_Currency&to=$to_Currency";
	$ch = curl_init();
	$timeout = 0;
	curl_setopt ($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$rawdata = curl_exec($ch);
	curl_close($ch);
	$data = explode('bld>', $rawdata);
	$data = explode($to_Currency, $data[1]);
	return round($data[0], 2);
} 
function deposit($amount,$fid,$detail="",$status=1,$fromid="",$Ismail=1){
	global $db;
	
	if($fromid=="")$fromid=$_SESSION["user"]["uid"];
	$data = array(	 'userid'=>$fid,
					 'fromid'=>$fromid,
					 'type'=>"deposit",
					 'amount'=>$amount,
					 'status'=>$status,
					 'detail'=>$detail);
	$did = $db->insertAry(TRANS,$data);
	$nid=notification("deposit : ".$amount." ".$cur." - ".$detail,"deposit","1",$fromid,$did,PATH_ADMIN."/?page_id=admin_user");
	if($Ismail==1){
		$subject="Depost your account on:".URL_ROOT;
		mymail($LinksDetails["mail_sender_email"],myFriendDetail($fromid,"useremail"),$subject,$detail,'TRANSECTION');
	}
	return array("did"=>$did,"nid"=>$nid);
}
function withdraw($amount,$fid,$detail="",$status=1,$userid="",$Ismail=1){
	global $db;
	if($userid=="")$userid=$_SESSION["user"]["uid"];
	$balance=getBalance();
	if($balance>$amount){
		$data = array(	 'userid'=>$userid,
						 'fromid'=>$fid,
						 'type'=>"withdraw",
						 'amount'=>$amount,
						 'status'=>$status,
						 'detail'=>$detail);
		$did = $db->insertAry(TRANS,$data);
		$nid=notification("withdraw : ".$amount." ".$cur." - ".$detail,"withdraw","1",$fromid,$did,PATH_ADMIN."/?page_id=admin_user");
		if($Ismail==1){
			$subject="Withdraw your account on:".URL_ROOT;
			mymail($LinksDetails["mail_sender_email"],myFriendDetail($userid,"useremail"),$subject,$detail,'COMMON');
		}
		return array("did"=>$did,"nid"=>$nid);
		return $inc;
	}else{
		return false;
	}
}
function savePackage($PackageId,$id){
	global $db;
	$st=$db->getRow("select * from ".MEMBERSHIPS." where id='".$PackageId."'");
	$IncAry=array("uid"=>$id,
					"mid"=>$PackageId,
					"price"=>$st["price"],
					"day"=>$st["day"],
					"status"=>1
					);
	$balance=getBalance();
	
	if($balance["balance"]>$st["price"] || $st["price"]==0){
		$ins=$db->updateAry(USERMEMBERSHIP,array("status"=>0),"where uid=".$id);
		$inc=$db->insertAry(USERMEMBERSHIP,$IncAry);
		//echo $db->getLastQuery().$db->getErMsg();exit;
		if(myDetail("payment_by")=="0"){
			if($st["is_default"]==0){//make entry only for non default package
				withdraw($st["price"],"Admin","Update Package from your old plan to <strong>".$st["name"]."</strong> Plan");
			}
		}
		
		return $inc=array("status"=>$inc,
				"message"=>$db->getErMsg()
		);
		
	}else{
		return $inc=array("status"=>0,
					"message"=>"You do not have sufficient balance for add package. Click <a href='".href('diposit.php')."'>here</a> to make deposit"
		);
	}
}
function replaceURL($url)
{
	$web=str_replace("www.", "", $_SERVER['HTTP_HOST']);
	$url = str_replace($_SERVER['HTTP_HOST'], $web, $url);
	return $url;
}
function getBalance($userid="",$type=""){
	global $db;
	$deposit=0;$withdraw=0;
		$deposittransection=$db->getRows("select * from ".TRANS." where userid='".$userid."' and type='deposit' and status=1");
		//echo "<pre>";print_r($deposittransection); echo $db->getErMsg()."//".$db->getLastQuery();exit;
	
	$withdrawtransection=$db->getRows("select * from ".TRANS." where fromid='".$userid."'  and  type='withdraw' and (status=1 or status=3) ");
	//echo "<pre>";print_r($withdrawtransection); echo $db->getErMsg()."//".$db->getLastQuery();exit;
	if(is_array($deposittransection) && count($deposittransection)>0){ 
		foreach($deposittransection as $dt){
				$deposit=$deposit+$dt["amount"];
		}
	}
	if(is_array($withdrawtransection) && count($withdrawtransection)>0){
		foreach($withdrawtransection as $wt){
				$withdraw=$withdraw+$wt["amount"];
		}
	}
	$balance = $deposit - $withdraw;
	return array("balance"=>(float)$balance,"earning"=>(float)$deposit,"expenses"=>(float)$withdraw); 
}
function imagecreatefromfile($image_path) {
    // retrieve the type of the provided image file
    list($width, $height, $image_type) = getimagesize($image_path);
    // select the appropriate imagecreatefrom* function based on the determined
    // image type
    switch ($image_type)
    {
      case IMAGETYPE_GIF: return imagecreatefromgif($image_path); break;
      case IMAGETYPE_JPEG: return imagecreatefromjpeg($image_path); break;
      case IMAGETYPE_PNG: return imagecreatefrompng($image_path); break;
      default: return ''; break;
    }
}
function smart_waterMark( $fileName, $watermark, $delete_original = false)
{
	// loads a png, jpeg or gif image from the given file name
	// load source image to memory
	$imageName=array_reverse(explode("/",$fileName));
	$file="";$w=0;$h=0;$folder="";
	if(is_numeric($imageName[1])){
		$file=$imageName[0];
		$w=$imageName[1];
		$h=$imageName[2];
		$folder=$imageName[3];
	}else{
		$file=$imageName[0];
		$folder=$imageName[2];
	}
	$image = imagecreatefromfile($fileName);
	if (!$image) die('Unable to open image'.$fileName);
	
	// load watermark to memory
	$watermark = imagecreatefromfile($watermark);
	if (!$image) die('Unable to open watermark'.$watermark);
	
	// calculate the position of the watermark in the output image (the
	// watermark shall be placed in the lower right corner)
	$watermark_pos_x = imagesx($image) - imagesx($watermark) - 8;
	$watermark_pos_y = imagesy($image) - imagesy($watermark) - 10;
	
	// merge the source image and the watermark
	imagecopy($image, $watermark,  $watermark_pos_x, $watermark_pos_y, 0, 0,
	imagesx($watermark), imagesy($watermark));
	
	// output watermarked image to browser
	
	$newpath=PATH_ROOT.DS."uploads".DS.$folder.DS."tm".DS.$file;
	imagejpeg($image, $newpath, 100);  // use best image quality (100)
	//imagejpeg($image);
	// remove the images from memory
	imagedestroy($image);
	imagedestroy($watermark);
	if($delete_original==true){
		@unlink(PATH_ROOT.DS."uploads".DS.$folder.DS.$file);
	}
	return $newpath;
}
function redirect($url=NULL){
	if(is_null($url)) $url=curPageURL();
	if(headers_sent())
	{
		echo "<script>window.location='".$url."'</script>";
	}
	else
	{
		header("Location:".$url);
	}
	exit;
}
function chkHeader(){
	if(strpos($_SERVER['HTTP_REFERER'],URL_ROOT)==0) return true;
	return false;
}
function getStock($pid){
	global $db;
	$st=$db->getVal("select stock from ".PRODUCT." where product_id='".$pid."'");
	return $st;
}
function selectfetch($fields="*",$table,$condition=""){
	$q = mysql_query("select $fields from $table $condition") or die("Select Error.".mysql_error());
	$r = mysql_fetch_object($q);
	return $r;
}
function loc($page){
	header("location:$page");
}
function update($table,$data,$condition=""){
	$fields="";
	$values = "";
	foreach($data as $key => $val)
	{
		$fields.=$key."='".$val."',";
	}
	$fields = substr($fields,0,strlen($fields)-1);
	
	$q = mysql_query("update $table set $fields $condition")or die("Update Error.".mysql_error());
	if($q)
	{
	return $q;
	}
}
function insert($table,$data){
	$fields="";
	$values = "";
	foreach($data as $key => $val)
	{
		$fields.=$key.',';
		$values.="'".$val."',";
	}
	$fields = substr($fields,0,strlen($fields)-1);
	$values = substr($values,0,strlen($values)-1);
	
	$q = mysql_query("insert into $table ($fields) values($values)") or die("Insert Error.".mysql_error());
	return mysql_insert_id();
}
function price($pid)
{
	$pquery=mysql_query("SELECT new_price FROM ".PRODUCT." WHERE product_id='$pid'");
	$pres=mysql_fetch_array($pquery);
	return $pres['new_price'];	
}
function getvalue($field, $table, $condition="")
{
	$q = mysql_query("select $field from $table $condition") or die(mysql_error());
	$row = mysql_fetch_array($q);
	return $row[$field];
}
function select($fields="*",$table,$condition="")
{
	$q = mysql_query("select $fields from $table $condition") or die("Select Query Error.".mysql_error());
	return $q;
}
function curPageURL() 
{
	$pageURL = 'http';
 	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 	$pageURL .= "://";
 	if ($_SERVER["SERVER_PORT"] != "80") 
	{
  		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 	} 
	else 
	{
  		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 	}
 	return $pageURL;
}
function getQueryString($aryQueryStr)
{
	$aryMatch=array();
	foreach($aryQueryStr as $opt=>$val) { $aryMatch[]=$opt.'='.urlencode($val); }
	return '?'.implode('&',$aryMatch);
}
function selected($needle,$haystack)
{
	if(is_array($haystack) && in_array($needle,$haystack)) { return 'selected="selected"'; }
	elseif(!is_array($haystack) && $needle===$haystack) { return 'selected="selected"'; }
	else { return ''; }
}
function checked($needle,$haystack)
{
	if(is_array($haystack) && in_array($needle,$haystack)) { return 'checked="checked"'; }
	elseif(!is_array($haystack) && $needle===$haystack) { return 'checked="checked"'; }
	else { return ''; }
}
function isValidDate($val)
{
	if(preg_match(REGX_DATE,$val))
	{
		list($year,$month,$date)=explode("-",$val);
		if(checkdate($month,$date,$year)) return true;
	}
	return false;
}
function getFileSize($path)
{
	if(is_array($path) && count($path)>0)
	{
		//if(!file_exists($path)) return 0;
		//if(is_file($path)) return filesize($path);
		$ret = 0;
		foreach($path as $file)
			$ret+=getFileSize($file);
		return $ret;
	}
	else
	{
		if(!file_exists($path)) return 0;
		if(is_file($path)) return filesize($path);
	}
}
function getRealIpAddr()
{
    if(!empty($_SERVER['HTTP_CLIENT_IP']))//check ip from share internet
    { 
		$ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))//to check ip is pass from proxy
    { 
		$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    { 
		$ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
function fetchSetting()
{
	$aryReturn=array();
	$strSetting='';
	
		global $db;
		$arySetData=$db->getRows("select * from ".SETTINGS);
		if(is_array($arySetData) && count($arySetData)>0)
		{
			$v=$_SESSION["lang"];
			foreach($arySetData as $iSetData)
			{
				$aryReturn[$iSetData['field']]=unPOST($iSetData[$v]);
			}
		}//echo $v;exit;
	return $aryReturn;
}
function getStatusImg($status)
{
	$aryImg=array(
				  '0'=>"status_inactive.png",
				  '1'=>"status_active.png"
				  );
	return '<img src="'.URL_ADMIN_IMGAGES.$aryImg[$status].'" title="'.getStatusStr($status).'" />';
}
function getStImg($status)
{
	$aryImg=array(
				  'Pending'=>"status_pending.png",
				  'Cancelled'=>"status_pending.png",
				  'Success'=>"status_active.png",
				  'Shipped'=>"status_pending.png"
				  );
	return '<img src="'.URL_ADMIN_IMG.$aryImg[$status].'" title="'.getStStr($status).'" />';
}
function getPImg($status)
{
	$aryImg=array(
				  'Incomplete'=>"status_pending.png",
				  'Cancelled'=>"status_pending.png",
				  'Completed'=>"status_active.png"
				  );
	return '<img src="'.URL_ADMIN_IMG.$aryImg[$status].'" title="'.getPStr($status).'" />';
}
function getOptionImg($status)
{
	$aryImg=array(
				  '0'=>"cross.png",
				  '1'=>"tick.png"
				  );
	return '<img src="'.URL_ADMIN_IMG."icons/".$aryImg[$status].'" />';
}
function getStatusStr($val)
{
	if($val==0)
	{
		return "Inactive";
	}
	else
	{
		return "Active";
	}
}
function getStStr($val)
{
	if($val=='Pending')
	{
		return "Pending";
	}
	elseif($val=='Cancelled')
	{
		return "Cancelled";
	}
	elseif($val=='Shipped')
	{
		return "Shipped";
	}
	else
	{
		return "Success";
	}
}
function getPStr($val)
{
	if($val=='Incomplete')
	{
		return "Incomplete";
	}
	elseif($val=='Cancelled')
	{
		return "Cancelled";
	}else
	{
		return "Completed";
	}
}
function getOptionStr($val)
{
	if($val==0)
	{
		return "No";
	}
	else
	{
		return "Yes";
	}
}
function delete_directory($dirname)
{
	if (is_dir($dirname))
      $dir_handle = opendir($dirname);
   if (!$dir_handle)
      return false;
   while($file = readdir($dir_handle))
   {
      if ($file != "." && $file != "..")
	  {
         if (!is_dir($dirname.DS.$file))
            @unlink($dirname.DS.$file);
         else
            delete_directory($dirname.DS.$file);    
      }
   }
   closedir($dir_handle);
   @rmdir($dirname);
   return true;
}
function listDirs($where){
	$directoryarr=array();
    $itemHandler=opendir($where);
    $i=0;
    while(($item=readdir($itemHandler)) !== false){
	if ($item == "." || $item == "..") { }
	else {$directoryarr[]=$item;}
       }
	  return($directoryarr);
}
function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
}
function enum_select( $table , $field )
{
	$query = "SHOW COLUMNS FROM `$table` LIKE '$field' ";
	$result = mysql_query( $query ) or die( 'error getting enum field ' . mysql_error() );
	$row = mysql_fetch_array( $result , MYSQL_NUM );
	#extract the values
	#the values are enclosed in single quotes
	#and separated by commas
	$regex = "/'(.*?)'/";
	preg_match_all( $regex , $row[1], $enum_array );
	$enum_fields = $enum_array[1];
	return( $enum_fields );
}
function randomFix($length,$add_dashes = false, $available_sets = 'luds')
{
	/*$random= "";
	
	srand((double)microtime()*1000000);
	
	$data = "AbcDE123IJKLMN67QRSTUVWXYZ";
	$data .= "aBCdefghijklmn123opq45rs67tuv89wxyz";
	$data .= "0FGH45OP89";
	
	for($i = 0; $i < $length; $i++)
	{
		$random .= substr($data, (rand()%(strlen($data))), 1);
	}
	return $random;*/
	$sets = array();
	if(strpos($available_sets, 'l') !== false)
		$sets[] = 'abcdefghjkmnpqrstuvwxyz';
	if(strpos($available_sets, 'u') !== false)
		$sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
	if(strpos($available_sets, 'd') !== false)
		$sets[] = '23456789';
	if(strpos($available_sets, 's') !== false)
		$sets[] = '!@#$%&*?';
	$all = '';
	$password = '';
	foreach($sets as $set)
	{
		$password .= $set[array_rand(str_split($set))];
		$all .= $set;
	}
	$all = str_split($all);
	for($i = 0; $i < $length - count($sets); $i++)
		$password .= $all[array_rand($all)];
	$password = str_shuffle($password);
	if(!$add_dashes)
		return $password;
	$dash_len = floor(sqrt($length));
	$dash_str = '';
	while(strlen($password) > $dash_len)
	{
		$dash_str .= substr($password, 0, $dash_len) . '-';
		$password = substr($password, $dash_len);
	}
	$dash_str .= $password;
	return $dash_str;
}
function href($page,$param="")
{
	global $db;
	$sef="1";
	if($sef=="1")
	{
		$x = explode("&",$param);
		$var = array();
		if(is_array($x) && count($x)>0){
			foreach($x as $k1 => $v1)
			{
				$x2 = explode("=",$v1);
				if(is_array($x2) && count($x2)>0){
					$subpar=$x2[0];
					$var[$subpar]=$x2[1];
				}
			}
		}
		switch($page)
		{
		case 'newupdates.php':
		{
			if(isset($var['id']) && isset($var['type'])){
				$name=$db->getRow("SELECT Name,link,image FROM ".CONTENT." WHERE id='".$var['id']."'");
				$pagename=str_replace(" ","-",str_replace("/","~",str_replace("&","and",unPOST($name["Name"]))));
				$type=$db->getVal("select linkname from ".CONTENT_HEAD." where heading='".$var['type']."' and status=1");
				$type=str_replace(" ","-",str_replace("/","~",str_replace("&","and",$type)));
				if(trim($name["link"])!="" && $name["link"]!="&#35;" && $name["link"]!="#"){
					return $name["link"];
				}elseif($name["image"]!=""){
					return URL_ROOT."uploads/content/".$name["image"];
				}else{
					return URL_ROOT."updates/".$type."/".$var['id']."-".$pagename.".html";
				}
			}
		}
		
		case 'workspace.php':
		{
			if(isset($var['id']) && isset($var['type'])){
				$name=$db->getRow("SELECT wtype,banner FROM ".WORKSPACE." WHERE id='".$var['id']."'");
				$pagename=str_replace(" ","-",str_replace("/","~",str_replace("&","and",unPOST($name["wtype"]))));
				$type=$db->getVal("select linkname from ".CONTENT_HEAD." where heading='".$var['type']."' and status=1");
				$type=str_replace(" ","-",str_replace("/","~",str_replace("&","and",$type)));
				if(trim($name["link"])!="" && $name["link"]!="&#35;" && $name["link"]!="#"){
					return $name["link"];
				}elseif($name["image"]!=""){
					return URL_ROOT."uploads/content/".$name["image"];
				}else{
					return URL_ROOT."workspace".$type."/".$var['id']."&&".$pagename.".html";
				}
			}
		}
		
		case 'page.php' :
		{
			if(isset($var['page_id']))
			{
			  $name=$db->getVal("SELECT linkname FROM ".CMS." WHERE id='".$var['page_id']."'");
			  $pagename=str_replace(" ","-",str_replace("/","~",str_replace("&","and",$name)));
			  return URL_ROOT."info/".$pagename.".html";
			  //return URL_ROOT."pages.php?page_id=".$pagename;
			}
			break;
		}
		
		case 'image.php' :
		{
			//return IMG.URL_ROOT."uploads/".$var['path']."/".$var['file_name']."&w=".$var["w"]."&h=".$var["h"];
			if($var["w"]!="" && $var["h"]!="")
				return URL_ROOT."uploads/".$var['path']."/".$var["w"]."/".$var["h"]."/".$var['file_name'];
			elseif($var["w"]=="" && $var["h"]!="")
				return URL_ROOT."uploads/".$var['path']."/h/".$var["h"]."/".$var['file_name'];
			elseif($var["h"]=="" && $var["w"]!="")
				return URL_ROOT."uploads/".$var['path']."/w/".$var["w"]."/".$var['file_name'];
			else
				return URL_ROOT."uploads/".$var['path']."/".$var['file_name'];
		}
		case 'signup.php' :
		{
			return URL_ROOT."signup.html";
			break;
		}
		
	default:
			{
				if($param=="")
				{
				  return URL_ROOT.$page;
				}
				else
				{
				  return URL_ROOT.$page.'?'.$param;
				}
			}
		
		}
	
	}
	else
	{ 
		if($param=="")
		{
		  return URL_ROOT.$page;
		}
		else
		{
		  return URL_ROOT.'/'.$page.'?'.$param;
		}
	}	
}
function UpdateUserPosition($sort_order,$id,$table,$field){
	global $db;
	$query = 'UPDATE '.$table.' SET '.$field.' = '.($sort_order + 1).' WHERE id = '.$id;
	$result = mysql_query($query) or die(mysql_error().': '.$query);
}
function addvisit(){
	global $db;
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$findme   = 'MsAdmin';$findme1   = 'ajax';
	//$pos = ($url, $findme);
	if (strpos($url, $findme) == false && strpos($url, $findme1) == false) {
		$qry='CREATE TABLE IF NOT EXISTS `'.NO_VISIT.'` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `ndate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
		  `ip` varchar(150) NOT NULL,
		  `page` varchar(150) NOT NULL,
		  `no` int(11) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;';
		mysql_query($qry);
		
		
		$v_id=$db->getVal("select no from ".NO_VISIT." where ip='".$_SERVER['REMOTE_ADDR']."' and page='".$url."'");
		if(strlen($url)<100){
			if($v_id==''){
				$VisitData=array("ip"=>$_SERVER['REMOTE_ADDR'],
								"page"=>$url,
								"no"=>1
				);
				$flgVisi=insert(NO_VISIT,$VisitData);
				//print_r($VisitData);
			}else{
				$VisitData=array("no"=>($v_id+1));
				$flgVisi=update(NO_VISIT,$VisitData,"where ip='".$_SERVER['REMOTE_ADDR']."' and page='".$url."'");
			}
		}
	}
}
function countVisits(){
	global $db;
	$cnt=$db->getRows("select no from ".NO_VISIT);
	$all=0;
	if(is_array($cnt) && count($cnt)>0){
		foreach($cnt as $ct){
			$all=$all+$ct["no"];
		}
	}
	return $all;
}
function mysms($m,$msg,$ret=0){
	$page=curPageURL(); 
	global $LinksDetails,$db; 
	if((strlen($m)==10 || strlen($m)==12) && is_numeric($m)){
		$api_key = '557C69FC9C7D44';
		$contacts = $m;
		$from = 'FIXNDL';
		$sms_text = urlencode($msg);
		
		$api_url = "http://mysms.mssinfotech.com/app/smsapi/index.php?key=".$api_key."&routeid=288&type=text&contacts=".$contacts."&senderid=".$from."&msg=".$sms_text;
		
		//Submit to server
		
		$ret = file_get_contents( $api_url);
		$db->insertAry(SMS_HISTORY,array("smsfrom"=>"FIXNDL","smsto"=>$m,"sms_detail"=>$msg,"status"=>$ret));
		return $ret."<br />".$url." ".$db->getErMsg();
	}else{
		return "invalid mobile no";
	}
}
function mymail($from,$to,$subject,$body,$type="Common",$ary=array(),$attach="0")
{
	global $db,$LinksDetails;$Stat="0";$sendFrom="";
	$st=$db->getVal("select status from ".UNSUBSCRIBE." where mto='".$to."' and type='".$type."'");
	if($st==1){
		return "You are unsubscribe for ".$type." section";
	}else{
		$UNSUBSCRIBE=URL_ROOT.'verification.php?to='.base64_encode($to).'&unsubscribe=yes&type=$type';
		$msgs=$db->getRow("select * from ".MAILMSG." where msg_for='".$type."'");
		$subject=$msgs['subject'];
		if(is_array($ary) && count($ary)>0){
		foreach($ary as $key=>$val){
			$arr_tpl_vars[]=$key;
			$arr_tpl_data[]=$val;
		}
		}else{
			$arr_tpl_vars = array('[MESSAGE]','[ADMIN]','[LOGIN]','[SITE]', '[DATE]','[SUBJECT]');
			$arr_tpl_data = array($body, $LinksDetails["admin_email"], URL_ROOT, URL_ROOT, date('d/m/Y'),$subject);
		}
		$e_msg = str_replace($arr_tpl_vars, $arr_tpl_data, unPOST($msgs["msg"]));
		$e_sub = str_replace($arr_tpl_vars, $arr_tpl_data, $subject);
		$body = $subject;
		if($LinksDetails["email_from"]=="server"){
			
			$mail = new PHPMailer();
			$mail->IsSMTP();
			//$mail->SMTPDebug = 1;
			$mail->SMTPAuth   = true;
			$mail->SMTPSecure = MAIL_SMTPSECURE;
			$mail->Host       = MAIL_HOST;
			$mail->Port       = MAIL_PORT; // we changed this from 486
			$mail->Username   = MAIL_USERNAME;
			$mail->Password   = MAIL_PASSWORD;
			// Build the message
			$mail->Subject = $e_sub;
			$mail->AltBody = 'This is a plain-text message body';
			if($attach!="0"){
				$mail->addAttachment($attach);
			}
			//Set the from/to
			$mail->setFrom(MAIL_SENDER_EMAIL, MAIL_SENDER_NAME);
			$mail->addAddress($to, $to);
			$mail->Body = unPOST($e_msg);
			//send the message, check for errors
			$Stat=$mail->Send();
			$sendFrom="server";
		
		}else{
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: <test@fixndeal.com>' . "\r\n";
			/*$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$headers .= 'From: '.MAIL_SENDER_NAME.'<'.MAIL_SENDER_EMAIL.'>' . "\r\n";*/
			if(@mail($to,$subject,$e_msg,$headers))
			$Stat="1";
			$sendFrom="local";
		}
		$added_by=$_SESSION["user"]["uid"];
		if($added_by=="")$added_by=$_SESSION['admin']['uid'];
		$db->insertAry(MAIL_HISTORY,array("ufrom"=>MAIL_SENDER_EMAIL,"uto"=>$to,"usubject"=>$subject,"ubody"=>$e_msg,"utype"=>$sendFrom,"status"=>$Stat,"added_by"=>$added_by,"page"=>curPageURL()));
		
		return $Stat."-".$sendFrom."<hr/>".MAIL_SENDER_NAME."-".MAIL_SENDER_EMAIL."<br/>".$to."<br/>".$subject."<br/>".$e_msg."<br/>".$db->getErMsg()."<br />Error=>".$mail->ErrorInfo;
	}
}
function sms($no,$msg,$type="0",$page=""){
	if($page=="")$page=curPageURL(); global $LinksDetails; 
	if(strlen($m)==10 && is_numeric($m))
		$status=sendSMS("91".$m,$msg,$page);
	elseif(strlen($m)==12 && is_numeric($m))
		$status=sendSMS($m,$msg,$page);
	else
		$status="invalid mobile no";
}
function sendSMS($m,$msg,$page){
	global $db;global $LinksDetails;
	$ID = trim(SMSID);
	$Pwd = trim(SMSPWD);
	//http://203.212.70.200/smpp/sendsms?username=punemn&password=punemn123&to=919907687825&from=CELLXx&udh=&text=test%20from%20msinfo&dlr-mask=19&dlr-url
	$baseurl ="http://203.212.70.200/smpp/";
	$PhNo = $m;
	$Text = urlencode($msg);
	//Invoke HTTP Submit url
	//$url = "$baseurl/sms.aspx?Id=$ID&Pwd=$Pwd&PhNo=$PhNo&text=$Text";
	$url=$baseurl."sendsms?username=".$ID."&password=".$Pwd."&from=CELLXx&to=".$PhNo."&text=".$msg."&dlr-mask=19&dlr-url&udh=";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	$ret = curl_exec($ch);
	curl_close($ch);
	// do sendmsg call
	//$ret = file_get_contents($url);
	//$res=$db->insertAry("sms",array("mobile"=>$m, "school_id"=>$_SESSION["admin"]["school_id"],"added_by"=>$_SESSION["admin"]["uid"],"msg"=>$msg,"status"=>$ret,"session"=>$_SESSION["admin"]["session"],"page"=>$page));
	return $ret;
}
function notification($notice,$type,$status='1',$added_by='',$id='',$url=''){
	global $db;
	/*$notice=notice or diescription
$type="user widthdraw desposite bid or ads"
$status='0 for read already 1 for admin 2 for user'
$added_by='session id who add this notice'
$id=if 1 then primary key of action
    if 2 then userid who need to recieve
$url='redirect url'*/
	$for="admin";
	if($status=="2")$for="user";
	$incData=array("notice"=>$notice,
					"nfor"=>$for,
				   "type"=>$type,
				   "status"=>$status,
				   "added_by"=>$added_by,
				   "pid"=>$id,
				   "url"=>$url
	);
	$res=$db->insertAry(NOTIFICATION,$incData);
	if($status=="2"){
		$regid=$db->getVal("select regId from ".SITE_USER." where id='".$id."'");
		if($regid!="")
		push_notification($regid,$notice);
	}
	return $res;
}
function push_notification($registatoin_ids, $message, $Image="") {
	$registrationIds = array($registatoin_ids);
	// prep the bundle
	$msg = array
	(
		'message'       => $message,
		'image'         => $Image,
	);
	
	$fields = array
	(
		'registration_ids'  => $registrationIds,
		'data'              => $msg
	);
	
	$headers = array
	(
		'Authorization: key=' . GOOGLE_API_KEY,
		'Content-Type: application/json'
	);
	
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
	curl_setopt( $ch,CURLOPT_POST, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	$result = curl_exec($ch );
	curl_close( $ch );		
	echo $result;
}
function getDirectorySize($path) 
{ 
  $totalsize = 0; 
  $totalcount = 0; 
  $dircount = 0; 
  if ($handle = opendir ($path)) 
  { 
    while (false !== ($file = readdir($handle))) 
    { 
      $nextpath = $path . '/' . $file; 
      if ($file != '.' && $file != '..' && !is_link ($nextpath)) 
      { 
        if (is_dir ($nextpath)) 
        { 
          $dircount++; 
          $result = getDirectorySize($nextpath); 
          $totalsize += $result['size']; 
          $totalcount += $result['count']; 
          $dircount += $result['dircount']; 
        } 
        elseif (is_file ($nextpath)) 
        { 
          $totalsize += filesize ($nextpath); 
          $totalcount++; 
        } 
      } 
    } 
  } 
  closedir ($handle); 
  $total['size'] = $totalsize; 
  $total['count'] = $totalcount; 
  $total['dircount'] = $dircount; 
  return $total; 
} 
function sizeFormat($size) { 
	$size=round($size/(1024*1024),1); 
    return $size; 
/*
    if($size<1024) 
    { 
        return $size." bytes"; 
    } 
    else if($size<(1024*1024)) 
    { 
        $size=round($size/1024,1); 
        return $size." KB"; 
    } 
    else if($size<(1024*1024*1024)) 
    { 
        $size=round($size/(1024*1024),1); 
        return $size." MB"; 
    } 
    else 
    { 
        $size=round($size/(1024*1024*1024),1); 
        return $size." GB"; 
    } 
*/
} 
//to find the time in diff format eg. 5 min ago
function ago($ptime)  //to find the time in diff format eg. 5 min ago
{
	/*if(empty($date)) {
       return "No date provided";
    }
    $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths         = array("60","60","24","7","4.35","12","10");
    
    $now             = time();
    $unix_date         = strtotime($date);
       // check validity of date
    if(empty($unix_date)) {    
        return "Bad date";
    }
    // is it future date or past date
    if($now > $unix_date) {    
        $difference     = $now - $unix_date;
        $tense         = "ago";
    } else {
        $difference     = $unix_date - $now;
        $tense         = "from now";
    }
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
        $difference /= $lengths[$j];
    }
    $difference = round($difference);
    
    if($difference != 1) {
        $periods[$j].= "s";
    }
    return "$difference $periods[$j] {$tense}";*/
	$etime = time() - strtotime($ptime);
    if ($etime < 1)
    {
        return 'Just now';
    }
    $a = array( 12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
                );
    foreach ($a as $secs => $str)
    {
        $d = $etime / $secs;
        if ($d >= 1)
        {
            $r = round($d);
            return $r . ' ' . $str . ($r > 1 ? 's' : '') . ' ago';
        }
    }
}
function website($url){
	if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
        $url = "http://" . $url;
    }
    return $url;
}
function checkWebsite($url,$id){
	if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
        return href("page.php","page_id=".$id);
    }else{
		return $url;
	}
}
function randid(){
	md5(microtime());
}
function getBrowser() 
{ 
    $u_agent = $_SERVER['HTTP_USER_AGENT']; 
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version= "";
    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }
    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Internet Explorer'; 
        $ub = "MSIE"; 
    } 
    elseif(preg_match('/Firefox/i',$u_agent)) 
    { 
        $bname = 'Mozilla Firefox'; 
        $ub = "Firefox"; 
    } 
    elseif(preg_match('/Chrome/i',$u_agent)) 
    { 
        $bname = 'Google Chrome'; 
        $ub = "Chrome"; 
    } 
    elseif(preg_match('/Safari/i',$u_agent)) 
    { 
        $bname = 'Apple Safari'; 
        $ub = "Safari"; 
    } 
    elseif(preg_match('/Opera/i',$u_agent)) 
    { 
        $bname = 'Opera'; 
        $ub = "Opera"; 
    } 
    elseif(preg_match('/Netscape/i',$u_agent)) 
    { 
        $bname = 'Netscape'; 
        $ub = "Netscape"; 
    } 
    // finally get the correct version number
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }
    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }
    // check if we have a number
    if ($version==null || $version=="") {$version="?";}
    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
}
function CSVExport($table,$filename = 'export.csv'){
	$csv_terminated = "\n";
	$csv_separator = ",";
	$csv_enclosed = '"';
	$csv_escaped = "\\";
	$sql_query = "select * from $table";
 
	// Gets the data from the database
	$result = mysql_query($sql_query);
	$fields_cnt = mysql_num_fields($result);
 
 
	$schema_insert = '';
 
	for ($i = 0; $i < $fields_cnt; $i++)
	{
		$l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
			stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		$schema_insert .= $l;
		$schema_insert .= $csv_separator;
	} // end for
 
	$out = trim(substr($schema_insert, 0, -1));
	$out .= $csv_terminated;
 
	// Format the data
	while ($row = mysql_fetch_array($result))
	{
		$schema_insert = '';
		for ($j = 0; $j < $fields_cnt; $j++)
		{
			if ($row[$j] == '0' || $row[$j] != '')
			{
 
				if ($csv_enclosed == '')
				{
					$schema_insert .= $row[$j];
				} else
				{
					$schema_insert .= $csv_enclosed .
					str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
				}
			} else
			{
				$schema_insert .= '';
			}
 
			if ($j < $fields_cnt - 1)
			{
				$schema_insert .= $csv_separator;
			}
		} // end for
 
		$out .= $schema_insert;
		$out .= $csv_terminated;
	} // end while
	//header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	//header("Content-Length: " . strlen($out));
	// Output to browser with appropriate mime type, you choose ;)
	header('Content-type: application/csv');
	//header("Content-type: text/x-csv");
	//header("Content-type: text/csv");
	header("Content-Disposition: attachment; filename=$filename");
	echo $out;
	exit;
 
}
function backup_tables($tables = '*'){
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return.= 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	
	//save file
	$handle = fopen('backup_database/db-backup-'.date("dMY").'.sql','w+');
	fwrite($handle,$return);
	ob_start();
	fclose($handle);
	header('Content-type: application/octet-stream');
	header('Content-Disposition: attachment; filename=db-backup-'.date("dMY").'-'.(md5(implode(',',$tables))).'.sql');
	echo $return;
}
if(!function_exists ( 'POST' )){
	function POST($i, $trim = false)
	{ 
		if(isset($_REQUEST[$i]))$i=$_REQUEST[$i];
		if ($trim)
			$i = trim($i);
		if (!get_magic_quotes_gpc())
			$i = addslashes($i);
		$i = rtrim(str_replace("'","`",$i));
		$look = array('&', '#', '<', '>', '"', '\'', '(', ')', '%');
		$safe = array('&amp;', '&#35;', '&lt;', '&gt;', '&quot;', '&#39;', '&#40;', '&#41;', '&#37;');
		$i = str_replace($look, $safe, $i);
		//$i = htmlentities($i);
		return $i;
	}
	function unPOST($i)
	{
		global $db;
		$look = array('&', '#', '<', '>', '"', '\'', '(', ')', '%');
		$safe = array('&amp;', '&#35;', '&lt;', '&gt;', '&quot;', '&#39;', '&#40;', '&#41;', '&#37;');
		$i = str_replace($safe, $look, $i);
		$msg=$i;/*$codesToConvert=array();
		$arr_tpl_vars=array();$arr_tpl_data=array();
		$shortcodes=$db->getRows("select code,image from ".SMILEYS." where status=1");
		if(is_array($shortcodes) && count($shortcodes)>0){
			foreach($shortcodes as $code){
				if (strpos($i, $code["code"]) != false) {
					$arr_tpl_vars[]=$code["code"];
					$arr_tpl_data[]="<img src='".URL_ROOT."uploads/smileys/".$code["image"]."' height='32px' />";	
				}
			}
			$msg = str_replace($arr_tpl_vars, $arr_tpl_data, $i);
		}*/
		return stripslashes($msg);//.$db->getErMsg();
	}
}
function checkPermission($pagename,$roll){
	global $db;
	$cando=0;
	$per=$db->getRow("select * from ".PRIVILAGES." where page_name='".strtolower($pagename)."' and roll_id=$roll");
	//echo $db->getErMsg().$db->getLastQuery();
	if($per["a"]==1){$cando="1";}
	return $cando;
}
function getAvgRating($pid) 
{ 
	$tot=0;
	global $db;
	$count=$db->getVal("select count(sid) from ".RATING." where sid='".$pid."'");
	$getsum=$db->getRows("select * from ".RATING." where sid='".$pid."'");
	$new_count=$count*5;
	foreach($getsum as $val)
	{
		$tot+=$val['rating_count'];
	}
	$avg=($tot*100)/$new_count;
	return $avg;
} 
function getAds($type){
	global $db;
	$detail=$db->getRow("select * from ".ADS." where banner_type='".$type."' and status=1 limit 0,1");
	return $detail;
}
function getPagination($count){
      $paginationCount= floor($count / PAGE_PER_NO);
      $paginationModCount= $count % PAGE_PER_NO;
      if(!empty($paginationModCount)){
               $paginationCount++;
      }
      return $paginationCount;
}
function latlng($url){
	$prepAddr = str_replace(' ','+',$url);
		
	$geocode=file_get_contents('http://maps.google.com/maps/api/geocode/json?address=' . $prepAddr . '&sensor=false');
	
	$output= json_decode($geocode);
	
	$myLat = $output->results[0]->geometry->location->lat;
	$myLng = $output->results[0]->geometry->location->lng;
	
	$address = $output->results[0]->address_components[1]->long_name.", ".$output->results[0]->address_components[2]->long_name.", ".$output->results[0]->address_components[3]->long_name;
	
	return(array("lat"=>$myLat,"lng"=>$myLng,"address"=>$address));
}
function geoCheckIP($ip)
{
	//check, if the provided ip is valid
	if(!filter_var($ip, FILTER_VALIDATE_IP))
	{
		throw new InvalidArgumentException("IP is not valid");
	}
	$response=@file_get_contents('http://www.netip.de/search?query='.$ip);
	if (empty($response))
	{
		throw new InvalidArgumentException("Error contacting Geo-IP-Server");
	}
	 
	//Array containing all regex-patterns necessary to extract ip-geoinfo from page
	 
	$patterns=array();
	$patterns["domain"] = '#Domain: (.*?)&nbsp;#i';
	$patterns["country"] = '#Country: (.*?)&nbsp;#i';
	$patterns["state"] = '#State/Region: (.*?)<br#i';
	$patterns["town"] = '#City: (.*?)<br#i';
	//Array where results will be stored
	$ipInfo=array();
	//check response from ipserver for above patterns
	foreach ($patterns as $key => $pattern)
	{
		//store the result in array
		$ipInfo[$key] = preg_match($pattern,$response,$value) && !empty($value[1]) ? $value[1] : 'not found';
	}
	/*I've included the substr function for Country to exclude the abbreviation (UK, US, etc..)
	To use the country abbreviation, simply modify the substr statement to:
	substr($ipInfo["country"], 0, 3)
	*/
	$ipdata = $ipInfo["town"]. ", ".$ipInfo["state"].", ".substr($ipInfo["country"], 4);
	return $ipdata;
}function myDetail($what){
	global $db;
	$st=$db->getVal("select $what from ".SITE_USER." where id='".$_SESSION["user"]["uid"]."'");
	return $st;
}
function myFriendDetail($id,$what){
	global $db;
	$st=$db->getVal("select $what from ".SITE_USER." where id='".$id."'");
	return $st;//$db->getLastQuery();
}
function update_info($detail){
	global $db;
	$Savedate=array(
					"update_by"=>$_SESSION["user"]["uname"],
					"Detail"=>$detail,
					"status"=>0,
					"userid"=>$_SESSION["user"]["uid"]
	);
	$db->insertAry(UPDATE_INFO,$Savedate);
}
function findage($birthDate){
	//$birthDate = "12/17/1983";
	//explode the date to get month, day and year
	$birthDate = explode("/", $birthDate);
	//get age from date or birthdate
	$age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
	? ((date("Y") - $birthDate[2]) - 1)
	: (date("Y") - $birthDate[2]));
	echo $age;
}
function getCount($what,$table,$where="")
{
global $db;
$r=$db->getVal("select count('".$what."') from ".$table.$where);	
return 	$r;
}
function isMobile(){
    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
		
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
	/*
	echo ip_info("Visitor", "Country"); // India
	echo ip_info("Visitor", "Country Code"); // IN
	echo ip_info("Visitor", "State"); // Andhra Pradesh
	echo ip_info("Visitor", "City"); // Proddatur
	echo ip_info("Visitor", "Address"); // Proddatur, Andhra Pradesh, India
	echo ip_info("Visitor", "Location"); // Array ( [city] => Proddatur [state] => Andhra Pradesh [country] => India [country_code] => IN [continent] => Asia [continent_code] => AS )
	*/
}
?>