<?php
/*******************************************************************************
 *                      PHP PayUMoney Integration Class
 *******************************************************************************
 *      Author:     Mragank shekhar soni
 *      Email:      mragnkshekhar@ms2fun.com
 *      Website:    http://www.mssinfotech.com
 *
 *      File:       class.payumoney.php
 *      Version:    1.00
 *      
 *******************************************************************************
 *  VERION HISTORY:
 *  
 *      v1.0.0 [04.16.2005] - Initial Version
 *
 *      To submit an order to PayUMoney, have your order form POST to a file with:
 *
 *          $p = new payumoney_class;
 *          $p->add_field('Amount', '10.00');
 *          $p->add_field('billing_cust_name', $_POST['billing_cust_name']);
 *          ... (add all your fields in the same manor)
 *          $p->submit_payumoney_post();
 *
 *******************************************************************************
 *      To process an demo test process
 *		put the words "SUB MERCHANT TEST" in the "Other Notes or Instructions"
 *          $p = new payumoney_class;
 *          $p->add_field('Instructions', 'SUB MERCHANT TEST');
*/
class payumoney_class {
    
   var $last_error;                 // holds the last error encountered
   
   var $ipn_log;                    // bool: log IPN results to text file?
   var $ipn_log_file;               // filename of the IPN log
   var $ipn_response;               // holds the IPN response from paypal   
   var $ipn_data = array();         // array contains the POST values for IPN
   
   var $fields = array();           // array holds the fields to submit to paypal

   
   function payumoney_class() {
       
      // initialization constructor.  Called when class is created.
      
      $this->last_error = '';
      $this->SALT	=	'GQs7yium';
	  $this->PAYU_BASE_URL = 'https://test.payu.in/';
      
   }
   
   function add_field($field, $value) {
      $this->fields["$field"] = $value;
   }

   function submit_payumoney_post() {
		$action='';
    	$posted = array();
		$SALT=$this->SALT;
		$PAYU_BASE_URL=$this->PAYU_BASE_URL;
		foreach ($this->fields as $key => $value) {
			$posted[$key] = $value; 
		}
		$formError = 0;
		$txnid=rand(0,5000);
		if(empty($posted['txnid'])) {
		  // Generate random transaction id
		  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
		} else {
		  $txnid = $posted['txnid'];
		}
		$this->add_field("txnid",$txnid);
		$hash = '';
		// Hash Sequence
		$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
		if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
		  || empty($posted['service_provider'])
  ) {
    			$formError = 1;
			} else {//$posted['productinfo']=json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
				$hashVarsSeq = explode('|', $hashSequence);
				$hash_string = '';	
				foreach($hashVarsSeq as $hash_var) {
				  $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
				  $hash_string .= '|';
				}
			
				$hash_string .= $SALT;
			
			
				$hash = strtolower(hash('sha512', $hash_string));
				$action = $PAYU_BASE_URL . '/_payment';
			}
	    }
		elseif(!empty($posted['hash'])) {
			$hash = $posted['hash'];
  			$action = $PAYU_BASE_URL . '/_payment';
		}
		if($action!=""){
			echo "<html>\n";
			echo "<head><title>Processing Payment...</title></head>\n";
			echo "<body onLoad=\"document.form.submit();\">\n";
			echo "<body>\n";
			echo "<center><h3>Please wait, your order is being processed...</h3></center>\n";
			echo "<form method=\"post\" name=\"form\" action=\"".$action."\">\n";
			echo "<input type=\"hidden\" name=\"hash\" value=\"$hash\"><br />";
			
			foreach ($this->fields as $name => $value) {
			 echo "<input type=\"hidden\" name=\"$name\" value=\"$value\"><br />";
			}
			//echo "<input type=\"submit\" name=\"same\" value=\"save\">";
			echo "</form>\n";
			echo "</body></html>\n";
		}else{
			echo "<center><h3>Please Check required field...</h3></center>\n";
		}
    }
}         


 