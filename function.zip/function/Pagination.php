<?php
class Pagination
{
	function getData($pagination){
		//print_r($pagination);
		$option="";
		if(isset ($pagination['option']))$option=$pagination['option'];
		$data = array();
		$pagestring="";
		$page = $pagination['nextpage'];
		$sqlfilter=$pagination['sqlfilter'];
		$size = $pagination['size'];
		$count=0;
		$pagecount=0;
		if(!empty($pagination['countMySql'])) {
			$mySql = $pagination['countMySql'];
		}
		else {
			$mySql ="select COUNT(*) AS totalRecord  from ". $pagination['table']." WHERE $sqlfilter ";
		}
		$sql =$mySql;
		//die;
		$result=mysql_query($sql) or die("Error Selecting data for pagination ".mysql_error(). " : ".$sql);
		$x=mysql_fetch_assoc($result);
		$totalRecord =$x['totalRecord'];// mysql_num_rows($result);
		//echo $totalRecord."/".$size;
		//print_r($size);
		$pagecount = ceil($totalRecord/$size);
		$page=$page>0 && $pagecount>=$page?$page:1;
		$start=($page-1)*$size;
		if($totalRecord>0)
		{
			if(!empty($pagination['mySql']))
			{
				$mySql = $pagination['mySql'];
			}
			else {
				$mySql ="select * from ". $pagination['table']." WHERE $sqlfilter ";
			}
			$finalSql ="  ".$mySql." limit ".$start." , ".$size."";
			$result = mysql_query($finalSql) or die("Error Selecting ". mysql_error()) ;
			while($x=mysql_fetch_assoc($result))
			{
				$data[] = $x;
			}
			$paginationData['total']=$totalRecord;
			$paginationData['targetpage']=$pagination['targetpage'];
			$pagestring = ($this->getPagination($pagecount,$size,$page,$option,$paginationData));
		}
		return $response = array ('data'=>$data,'pagestring'=>$pagestring,'totalRecord'=>$totalRecord);
	}
	function getPagination($total_pages,$limit,$page,$option,$paginationData)
	{
		//echo " total pages  ".$total_pages." limt : ".$limit." pages: ".$page." potion : ".$option;
		$adjacents = 5;
		$targetpage ="";
		$targetpage = $paginationData['targetpage'];
		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
								//last page minus 1
		//echo "lastpage : ".$lastpage;
		$lastpage = $total_pages;
		$lpm1 = $lastpage - 1;
		// $lastpage=$lastpage+1;
		/*
		Now we apply our rules and draw the pagination object.
		We're actually saving the code to a variable in case we want to draw it more than once.
		*/
		
		
		
		$pagination = "";
		//if($lastpage > 1)
		{
			$pagination .= "<div class=\"paginat\">";
			$pagination .= "<ul class=\"pagination\">";
			$pagination .= "<li class=\"pages\"><a>Page $page of $total_pages outof ".$paginationData["total"]."</a></li>";
			//previous button
			if ($page > 1)
			$pagination.= "<li class=\"first\"><a class=\"pre\" href=\"".href($targetpage,$option."&nextpage=$prev")."\"> Previous</a></li>";
			//else
			//	$pagination.= "<li class=\"first\">Previous</li>";
			
			//pages
			if ($lastpage <= 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
			{
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<li class='active'><a>$counter</a></li>";
					else
						$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$counter")."\">$counter</a></li>";
				}
			}
			elseif($lastpage >= 5 + ($adjacents * 2))	//enough pages to hide some
			{
				//close to beginning; only hide later pages
				if($page < 1 + ($adjacents * 2))
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
						$pagination.= "<li class='active'><a href=''>$counter</a></li>";
						else
						$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$counter")."\">$counter</a>";
					}
					$pagination.= "<li><a>...</a></li>";
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$lpm1")."\">$lpm1</a></li>";
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$lastpage")."\">$lastpage</a></li>";
				}
				//in middle; hide some front and some back
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=1")."\">1</a></li>";
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=2")."\">2</a></li>";
					$pagination.= "<a>...</a>";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<li class='active'><a href=''>$counter</a></li>";
						else
							$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$counter").">$counter</a></li>";
					}
					$pagination.= "<a>...</a>";
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$lpm1")."\">$lpm1</a></li>";
					$pagination.= "<li class=\"last\"><a class=\"nextal\" href=\"".href($targetpage,$option."&nextpage=$lastpage")."\">$lastpage</a></li>";
				}
				//close to end; only hide early pages
				else
				{
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=1")."\">1</a></li>";
					$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=2")."\">2</a><li>";
					$pagination.= "<a>...</a>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
						$pagination.= "<li class='active'><a href=''>$counter</a></li>";
						else
						$pagination.= "<li><a href=\"".href($targetpage,$option."&nextpage=$counter")."\">$counter</a></li>";
					}
				}
			}
			//$counter = $counter+1;
			//next button
			//echo "counter ". $counter." next :".$next;
			if ($page < $counter - 1)
			$pagination.= "<li class=\"last\"><a class=\"nextal\" href=\"".href($targetpage,$option."&nextpage=$next")."\">Next </a>";
			//else
			//	$pagination.= "<li class=\"last\">Next</li>";
			$pagination.= "</ul>\n";
			$pagination.= "</div>\n";
			
			
			
			return $pagination;
		}
	}
}
?>