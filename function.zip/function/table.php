 <?php 
define("POST_CATEGORY_CRITERIA",TABLE_PREFIX."posts_category_criteria");

define("SETTINGS",TABLE_PREFIX."settings");

define("DEALTYPE",TABLE_PREFIX."type");

define("REVIEWS",TABLE_PREFIX."buysell_reviews");

define("PUSH_NOTIFICATION",TABLE_PREFIX."push_notification");

define("TRANS",TABLE_PREFIX."transection");

define("NO_VISIT",TABLE_PREFIX."no_visit");

define("CATEGORY",TABLE_PREFIX."category");

define("COINSDETAIL",TABLE_PREFIX."coinsdetail");

define("CURRENCY",TABLE_PREFIX."currency");

define("CMS",TABLE_PREFIX."cms");

define("NOTIFICATION",TABLE_PREFIX."notification");

define("CONTENT",TABLE_PREFIX."content");

define("MEMBERSHIPS",TABLE_PREFIX."membership");

define("USERMEMBERSHIP",TABLE_PREFIX."user_membership");


define("ORDERDETAIL",TABLE_PREFIX."orderdetail");

define("MAILMSG",TABLE_PREFIX."mailmsg");

define("UPDATE_INFO",TABLE_PREFIX."update_info");

define("GALLERY",TABLE_PREFIX."gallery");

define("ROLL",TABLE_PREFIX."roll");

define("MENUS",TABLE_PREFIX."menus");

define("POSTS",TABLE_PREFIX."posts");

define("ALERT",TABLE_PREFIX."alertlist");


define("PRIVILAGES",TABLE_PREFIX."privilages");

define("RATING",TABLE_PREFIX."rating");

define("SITE_USER",TABLE_PREFIX."site_user");

define ('CHAT',TABLE_PREFIX.'chat');

define("COMMENT",TABLE_PREFIX."comment");

define("ADS",TABLE_PREFIX."ads");

define("MESSAGE",TABLE_PREFIX."messages");

define("MAIL_HISTORY",TABLE_PREFIX."email_history");

define("SMS_HISTORY",TABLE_PREFIX."sms_history");

define("UNSUBSCRIBE",TABLE_PREFIX."unsubscribe");

define("SLIDER",TABLE_PREFIX."slider");

define("PRODUCT",TABLE_PREFIX."product");

define("PRODUCT_CRITERIA",TABLE_PREFIX."product_criteria");

define("CONTACT",TABLE_PREFIX."contact");

define("FAQ_CATEGORY",TABLE_PREFIX."faq_category");

define("FAQS",TABLE_PREFIX."faq");

define("ADDRESS",TABLE_PREFIX."address_tb");

define("ORDER",TABLE_PREFIX."orders");

define("COUNTRY",TABLE_PREFIX."country");

define("LOGIN_HISTORY",TABLE_PREFIX."login_history");

define("CAREER",TABLE_PREFIX."career");

define("LANGUAGE",TABLE_PREFIX."language");

define("SLIDER_CONTENT",TABLE_PREFIX."slider_content");

define("QUOTE",TABLE_PREFIX."quote");

define("QUERY",TABLE_PREFIX."query");



define("FEE_DETAIL",TABLE_PREFIX."fee_detail");



define("CCLASS",TABLE_PREFIX."class");

define("SUBJECT",TABLE_PREFIX."subject");

define("FEES",TABLE_PREFIX."fees");

define("NOTICE",TABLE_PREFIX."notice");

define("ADMISSION",TABLE_PREFIX."admission");



define("ASSIGNMENT",TABLE_PREFIX."assignment");

define("NEWSLETTAR",TABLE_PREFIX."newslettar");
define("STUDENT",TABLE_PREFIX."student");

define("NON_USER",TABLE_PREFIX."non_user");

define("STUDENT_NOTICE",TABLE_PREFIX."student_notice");

define("FEE_COLLECT",TABLE_PREFIX."fee_collect");

define("QUESTION",TABLE_PREFIX."question");

define("PAPER",TABLE_PREFIX."papers");

define("COMPLAIN",TABLE_PREFIX."complain");

define("RESULT",TABLE_PREFIX."result");

define("EXAMDETAILS",TABLE_PREFIX."examdetails");

define("RECEIPT",TABLE_PREFIX."receipt");

define("CONTENT_HEAD",TABLE_PREFIX."content_head");

define("REATTEMPT",TABLE_PREFIX."reattempt");

define("DISALOCATE",TABLE_PREFIX."disalocate");

define("WORKSPACE",TABLE_PREFIX."workspace");

define("INFO",TABLE_PREFIX."spaceinfo");

define("SPACETYPE",TABLE_PREFIX."spacetype");

define("FACILITIES",TABLE_PREFIX."facilities");

define("CUSTOM_REQUEST",TABLE_PREFIX."custom_request");

define("TOUR",TABLE_PREFIX."tour");

define("FAV",TABLE_PREFIX."favourite");

define("PAY",TABLE_PREFIX."paymentInfo");

define("FOLLOW",TABLE_PREFIX."following");

define("WEEKD",TABLE_PREFIX."weekdetail");

define("SEARCH_HISTORY",TABLE_PREFIX."search_history");

define("citystatecountry","citystatecountry");


define("CATEGORYCRITERIA",TABLE_PREFIX."category_criteria");



?>

